cd preprocess/

    cuteeg
    disp('-------------cuteeg----------------')
cd ../

cd analysis/
    cd matlab/
        cd code_space
            preprocess_IIR
            disp('-------------space----------------')
        cd ../
        cd code_env/
            envelope_process_ear
            disp('-------------envelope----------------')
        cd ../
    cd ../
cd ../