%% TRF
clear
clc

EnvelopeDir = './';%提完包络的路径
load([EnvelopeDir 'space_envall.mat'],'space_env');%80个音频包络
load([EnvelopeDir 'space_num.mat'],'space_num');%对应的试次映射
EEGDataDir = '..\..\..\preprocess_data\data_env\';%输入的EEG文件
savepath = './trf/';
tauRange = [-50 450];
sblist = dir(EEGDataDir);
sblist(1:2) = [];

for i0=1:16
    disp(['---------Subject NO. ---------' num2str(i0)])
    subjectName = sblist(i0).name;
    subjectNameDir =[EEGDataDir filesep subjectName];
    DataSaveDir = [savepath subjectName];
    if exist(DataSaveDir,'dir')==0, mkdir(DataSaveDir); end
    
    % load EEG Data
    for EEGDataFileNo = 1:40
        EEGDataFileName = [subjectNameDir filesep num2str(EEGDataFileNo) '_cap.mat'];
        load(EEGDataFileName,'EEG_env');
        EEG = EEG_env;
        EEGdata = EEG.data; % channel by time
        fs1 = EEG.srate;
%         EEGdata(60:64,:) = [];% delete EoG
        EEGdata_temp = mapminmax(double(EEGdata),-1,1);
        respSet{EEGDataFileNo} = EEGdata_temp';
        AudioIndex(EEGDataFileNo)  = EEGDataFileNo;
    end
    lambda_index = [1:2:20]';
    lambda = 2.^lambda_index;
    Envelope_att = space_env(space_num(:,1),:);
    Envelope_unatt1 = space_env(space_num(:,2),:);
    Envelope_unatt2 = space_env(space_num(:,3),:);
    Envelope_unatt3 = space_env(space_num(:,4),:);

    % choose corresponding Audio Envelopes

    Envelope_att = mapminmax(Envelope_att,-1,1);
    Envelope_unatt1 = mapminmax(Envelope_unatt1,-1,1);
    Envelope_unatt2 = mapminmax(Envelope_unatt2,-1,1);
    Envelope_unatt3 = mapminmax(Envelope_unatt3,-1,1);

    % attended trf
    for i1=1:size(Envelope_att,1)
        stimSet{i1} = Envelope_att(i1,:)';
    end
    clear stimTrain stimTest respTrain respTest trfs con
    stimTrain = stimSet;
    respTrain = respSet;
    % train
    [r1,p1,MSE1,prediction,trfs,con] = mTRFcrossval(stimTrain,respTrain,fs1,1,tauRange(1),tauRange(2),lambda);
    save([DataSaveDir '/Variables_att.mat'],'trfs','r1','p1','MSE1','con')
    % unattended trf1
    for i1=1:size(Envelope_att,1)
        stimSet{i1} = Envelope_unatt1(i1,:)';
    end
    clear stimTrain stimTest respTrain respTest trfs con
    stimTrain = stimSet;
    respTrain = respSet;
    % train
    [r1,p1,MSE1,prediction,trfs,con] = mTRFcrossval(stimTrain,respTrain,fs1,1,tauRange(1),tauRange(2),lambda);
    save([DataSaveDir '/Variables_unatt1.mat'],'trfs','r1','p1','MSE1','con');

     % unattended trf2
    for i1=1:size(Envelope_att,1)
        stimSet{i1} = Envelope_unatt2(i1,:)';
    end
    clear stimTrain stimTest respTrain respTest trfs con
    stimTrain = stimSet;
    respTrain = respSet;
    % train
    [r1,p1,MSE1,prediction,trfs,con] = mTRFcrossval(stimTrain,respTrain,fs1,1,tauRange(1),tauRange(2),lambda);
    save([DataSaveDir '/Variables_unatt2.mat'],'trfs','r1','p1','MSE1','con');

     % unattended trf3
    for i1=1:size(Envelope_att,1)
        stimSet{i1} = Envelope_unatt3(i1,:)';
    end
    clear stimTrain stimTest respTrain respTest trfs con
    stimTrain = stimSet;
    respTrain = respSet;
    % train
    [r1,p1,MSE1,prediction,trfs,con] = mTRFcrossval(stimTrain,respTrain,fs1,1,tauRange(1),tauRange(2),lambda);
    save([DataSaveDir '/Variables_unatt3.mat'],'trfs','r1','p1','MSE1','con');

end

%% Calculate best TRF
% calculate best trf and corresponding r value for Prediction
lambda_index = 4;% 2^7
map = 1;
fs1 = 64;
tmin = tauRange(1);
tmax = tauRange(2);
tmin = floor(tmin/1e3*fs1*map);
tmax = ceil(tmax/1e3*fs1*map);
t = (tmin:tmax)/fs1*1e3;

%figure

for i_cond = 1:1
    for i0=1:16
        subjectName = sblist(i0).name;
        subjectNameDir =[EEGDataDir filesep subjectName];
        DataSaveDir = [savepath subjectName];
        load([DataSaveDir '/Variables_att.mat']);
        best_trfs_att(:,:,i0) = squeeze(mean(trfs(:,lambda_index,:,:),1));
        best_cons_att(:,i0) = squeeze(mean(con(:,lambda_index,:),1));

        load([DataSaveDir '/Variables_unatt1.mat']);
        best_trfs_unatt1(:,:,i0) = squeeze(mean(trfs(:,lambda_index,:,:),1));
        best_cons_unatt1(:,i0) = squeeze(mean(con(:,lambda_index,:),1));

        load([DataSaveDir '/Variables_unatt2.mat']);
        best_trfs_unatt2(:,:,i0) = squeeze(mean(trfs(:,lambda_index,:,:),1));
        best_cons_unatt2(:,i0) = squeeze(mean(con(:,lambda_index,:),1));
        load([DataSaveDir '/Variables_unatt3.mat']);
        best_trfs_unatt3(:,:,i0) = squeeze(mean(trfs(:,lambda_index,:,:),1));
        best_cons_unatt3(:,i0) = squeeze(mean(con(:,lambda_index,:),1));

        disp(['----Calculate Best TRFs---' num2str(i0)])


    end
    best_trf_att = mean(best_trfs_att,3);
    best_con_att = mean(best_cons_att,2);
    best_trf_unatt1 = mean(best_trfs_unatt1,3);
    best_con_unatt1 = mean(best_cons_unatt1,2);
    best_trf_unatt2 = mean(best_trfs_unatt2,3);
    best_con_unatt2 = mean(best_cons_unatt2,2);
    best_trf_unatt3 = mean(best_trfs_unatt3,3);
    best_con_unatt3 = mean(best_cons_unatt3,2);
    best_trfs = cat(3,best_trf_att,best_trf_unatt1,best_trf_unatt2,best_trf_unatt3);
    best_cons = [best_con_att,best_con_unatt1,best_con_unatt2,best_con_unatt3];
    
    for i0=1:16
        subjectName = sblist(i0).name;
        subjectNameDir =[EEGDataDir filesep subjectName];
        DataSaveDir = [savepath subjectName];
        save([DataSaveDir '/trf.mat'],'best_cons','best_trfs');
    end

end

%% Plot att_TRF and unatt_TRF for certain electrodes
EEGDataDir = '..\..\..\preprocess_data\data_env\';%输入的EEG文件
savepath = './trf/';
tauRange = [-50 450];
sblist = dir(EEGDataDir);
sblist(1:3) = [];
lambda_index = 4;% 2^7
map = 1;
fs1 = 64;
tmin = tauRange(1);
tmax = tauRange(2);
tmin = floor(tmin/1e3*fs1*map);
tmax = ceil(tmax/1e3*fs1*map);
t = (tmin:tmax)/fs1*1e3;
TRFFileName = '/trf.mat';
subjectName = sblist(1).name;
subjectNameDir =[EEGDataDir filesep subjectName];
DataSaveDir = [savepath subjectName];
load([DataSaveDir TRFFileName]);
figure
electrodesName = {'7', '20'};
electrodes = [7 20];
linestyle = {'-',':','--','-.'};
for i1 = 1:2
    elec = electrodes(i1);
    h(i1) = subplot(1,2,i1);
    hold on
    plot(t(5:end),best_trfs(5:end,elec,1), 'linewidth', 2.5, 'linestyle',linestyle{1});
    plot(t(5:end),(best_trfs(5:end,elec,2)+best_trfs(5:end,elec,3)+best_trfs(5:end,elec,4))/3, 'linewidth', 2.5, 'linestyle',linestyle{1},'Color','red');    
    plot(t(5:end),best_trfs(5:end,elec,2), 'linewidth', 2.5, 'linestyle',linestyle{2});
    plot(t(5:end),best_trfs(5:end,elec,3), 'linewidth', 2.5, 'linestyle',linestyle{3});
    plot(t(5:end),best_trfs(5:end,elec,4), 'linewidth', 2.5, 'linestyle',linestyle{4});

    line([0, 350], [0,0 ], 'Color', 'black','linewidth',1.0);
%     text(-10, 0, '0', 'HorizontalAlignment', 'right','FontSize',20,'FontWeight', 'bold','FontName','Times New Roman');
    axis([0 350 -2e-3 2e-3])
    set(gca,'FontWeight', 'bold','fontsize',20,'FontName','Times New Roman','ytick',[], 'linewidth', 1, 'xtick',[0:50:350],'ytick',[-2e-3:5e-4:2e-3]);
    text(160, 9e-3, electrodesName{i1}, 'fontsize',20,'FontName','Times New Roman','FontWeight', 'bold');
    xlabel('Time lag (ms)');
    ylabel('TRF amplitude (a.u.)');
    box off    
end
lg = legend('Att','Unatt_{avg}','Unatt_1','Unatt_2','Unatt_3','Location','eastoutside');
% set(lg, 'Position', [0.87 0.85 0.1 0.1])
set(lg, 'Position', [0.87 0.85 0.1 0.05])
set(lg, 'FontWeight', 'bold','fontsize',20, 'orientation', 'vertical', 'box', 'off','FontName','Times New Roman')